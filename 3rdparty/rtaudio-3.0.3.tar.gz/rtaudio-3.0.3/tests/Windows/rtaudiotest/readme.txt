rtaudiotest - Test rtaudio devices.

rtaudiotest is a small tool that allows easy testing of rtaudio devices
and configurations.

Run rtaudiotest.exe for a description of how to run it.

rtaudiotest is currently only supported for the Windows platform.
