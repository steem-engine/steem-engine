		   **************************************
		   * GAME WIZARD PRO USER MANUAL UPDATE *
		   **************************************

This file reflects the changes that have been made to Game Wizard Pro since
the manual was printed.

  - Please remember to use /x option for better compatability with DOS
    Extender games.

  - If you experience problems during the installation process, please remove
    all memory managers.

  - Updated the table file format to work correctly with the DOS Extender
    support.  You must run TBLUPDAT.EXE in Game Wizard Pro directory to
    convert all old cheat tables to the new format.

If you experience any problems or have any suggestions, please feel free to
call us at (416)492-0157.
